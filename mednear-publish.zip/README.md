# MedNear website deployment package

This folder contains the complete static site prepared for GitHub Pages. The app requires no server-side code. Its CSV and postcode-coordinate files are fetched from the same folder.

## Publish

1. Create a **public** GitHub repository named `mednear` and add every file in this folder to the repository root, including the hidden `.github` workflow and `.nojekyll` file.
2. In the repository, open **Settings → Pages** and choose **GitHub Actions** as the build and deployment source.
3. Push the files to the `main` branch. The included workflow publishes the site and provides the URL in its deployment status.

For a personal account, the address will normally be `https://YOUR-USERNAME.github.io/mednear/`. A custom domain can be connected later.

**Public access:** GitHub Pages websites are publicly accessible. The published site includes the supplied medicine and UK pharmacy CSV data, postcode coordinates, and invented demo inventory. Keep the pharmacy profiles marked as invented demo data. Do not use the sample inventory to guide purchases.

## Local preview

Run `python -m http.server 8765` in this folder, then open <http://localhost:8765>.

## Data and attribution

Medicine prices are displayed in KZT using the National Bank of Kazakhstan reference rate of 1 EGP = ₸9.33, checked on 16 Nov 2026. The supplied medicine list is dated 19 Nov 2024; the displayed KZT amount is a currency conversion, not a current local price.

The UK pharmacy register has no stock or price mapping. Profiles create six deterministic sample medicines per pharmacy; every availability, quantity, and pharmacy price is invented demo data. These details are not verified with pharmacies.

Postcode locations were resolved using [Postcodes.io](https://postcodes.io/docs/postcode/bulk/); map tiles come from [OpenStreetMap](https://www.openstreetmap.org/copyright) and use [Leaflet](https://leafletjs.com/).
